#include <stdio.h>

void data_swap1(int *data1, int *data2);
void data_swap2(int* ip1, int* ip2);
void data_swap3(int *array1[], int *array2[]);
void array_copy(int to[], int from[]);