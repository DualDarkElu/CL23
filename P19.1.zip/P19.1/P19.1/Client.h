#include <stdio.h>
#define MAX_LEN 20

