#include <stdio.h>

int my_op(int x, int y, int op);

#define PLUS 1
#define MINUS 2
#define MULTIPLY 3
#define DIVIDE 4
#define REMAINDER 5
#define EXPONENT 6