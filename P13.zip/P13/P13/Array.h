#include <stdio.h>

int input_student(int student[], int num);
float average_student(int student[], int i);
int max_student(int student[], int i);
int min_student(int student[], int i);
int sort_des_student(int student[], int i);
int sort_asc_student(int student[], int i);
int output_student(int student[], int i);
int backup_student(int student[], int backup[], int i);